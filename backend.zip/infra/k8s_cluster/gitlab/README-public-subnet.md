# GitLab with Public Nodes for HTTP-01 ACME Challenges

This guide explains how to deploy GitLab on EKS with nodes in public subnets to enable HTTP-01 ACME challenge validation for Let's Encrypt certificates.

## Why Public Subnets?

When your EKS nodes are in **private subnets** with an **internal load balancer**, Let's Encrypt cannot reach the HTTP-01 challenge endpoint to validate domain ownership. This causes certificate issuance to fail.

**Solutions:**
1. ✅ **Deploy nodes in public subnets** (this guide) - Nodes get public IPs, HTTP-01 works
2. ❌ ~~Use DNS-01 challenge with DuckDNS~~ - Blocked by ISP
3. Use a public load balancer (exposes GitLab to internet)

## Step 1: Update Terraform Configuration

### 1.1 Apply the Terraform Updates

The following files have been updated to support public subnet deployment:

- `infra/terraform/variables.tf` - Added `use_public_subnets` variable
- `infra/terraform/main.tf` - Pass public subnets to EKS module
- `infra/terraform/modules/eks/variables.tf` - Added public subnet variables
- `infra/terraform/modules/eks/main.tf` - Deploy nodes to public subnets when enabled

### 1.2 Create terraform.tfvars

```bash
cd d:\VTI\aws-rag-chatbot-ai\infra\terraform

# Copy the example file
cp terraform.tfvars.example terraform.tfvars

# Edit terraform.tfvars and set:
# use_public_subnets = true
```

### 1.3 Apply Terraform Changes

⚠️ **WARNING**: This will recreate your node group, causing temporary downtime.

```bash
# Review the plan
terraform plan

# Expected changes:
# - aws_eks_node_group.default will be replaced (subnet_ids change)
# - Nodes will be created in public subnets instead of private subnets

# Apply the changes
terraform apply
```

## Step 2: Update GitLab Load Balancer to Internet-Facing

The GitLab Ingress controller needs to use an **internet-facing** load balancer so Let's Encrypt can reach it.

### 2.1 Update gitlab-values.yaml

Edit `infra/k8s_cluster/gitlab/gitlab-values.yaml` and change the nginx-ingress service annotations:

```yaml
nginx-ingress:
  controller:
    service:
      type: LoadBalancer
      externalTrafficPolicy: "Cluster"
      annotations:
        service.beta.kubernetes.io/aws-load-balancer-type: "nlb"
        service.beta.kubernetes.io/aws-load-balancer-scheme: "internet-facing"  # Changed from "internal"
        service.beta.kubernetes.io/aws-load-balancer-cross-zone-load-balancing-enabled: "true"
        service.beta.kubernetes.io/aws-load-balancer-target-type: "ip"
```

### 2.2 Upgrade GitLab Helm Release

```bash
helm upgrade gitlab gitlab/gitlab \
  -n gitlab \
  -f ./infra/k8s_cluster/gitlab/gitlab-values.yaml \
  --set certmanager-issuer.email=baonguyen3197@gmail.com \
  --set global.hosts.domain=nhqb-gitlab.duckdns.org
```

### 2.3 Get the New Load Balancer Address

```bash
kubectl -n gitlab get svc gitlab-nginx-ingress-controller

# Wait for EXTERNAL-IP to be assigned (not <pending>)
# This will be a public AWS NLB hostname
```

### 2.4 Update DuckDNS with the New IP

```bash
# Get the IP address of the load balancer
nslookup <NLB-hostname-from-above>

# Update DuckDNS
# Go to https://www.duckdns.org
# Update nhqb-gitlab domain with the new public IP
```

## Step 3: Verify Certificate Issuance

### 3.1 Check Certificates

```bash
# Watch certificates
kubectl -n gitlab get certificate -w

# All should eventually show READY: True
# NAME                  READY   SECRET
# gitlab-gitlab-tls     True    gitlab-gitlab-tls
# gitlab-kas-tls        True    gitlab-kas-tls
# gitlab-minio-tls      True    gitlab-minio-tls
# gitlab-registry-tls   True    gitlab-registry-tls
```

### 3.2 Check Challenges (if certificates are pending)

```bash
# List challenges
kubectl -n gitlab get challenge

# Describe a challenge to see details
kubectl -n gitlab describe challenge <challenge-name>

# HTTP-01 challenges should now succeed since Let's Encrypt can reach the load balancer
```

### 3.3 Check cert-manager Logs

```bash
# Check cert-manager controller logs
kubectl -n cert-manager logs deploy/cert-manager --tail=50

# Look for successful challenge completion messages
```

## Step 4: Test GitLab Access

### 4.1 Access GitLab

```bash
# Get the root password
kubectl get secret gitlab-gitlab-initial-root-password -n gitlab -ojsonpath='{.data.password}' | base64 --decode ; echo
```

Open browser to: `https://nhqb-gitlab.duckdns.org`

- Username: `root`
- Password: (from above command)

### 4.2 Verify TLS Certificate

- Click the lock icon in the browser address bar
- Verify certificate is issued by **Let's Encrypt** (not self-signed)
- Check certificate validity period

## Architecture Overview

### Before (Private Subnets + Internal LB)
```
Internet
   │
   └─> ❌ Cannot reach internal LB
          │
          └─> Private Subnet
                 └─> EKS Nodes (no public IP)
```

### After (Public Subnets + Internet-Facing LB)
```
Internet
   │
   └─> Let's Encrypt
          │
          ├─> ✅ HTTP-01 challenge succeeds
          │
          └─> Internet-Facing NLB
                 │
                 └─> Public Subnet
                        └─> EKS Nodes (with public IPs)
```

## Security Considerations

### Public Nodes Security

Even though nodes are in public subnets:
- ✅ Security groups restrict access
- ✅ Only services exposed via Ingress are accessible
- ✅ SSH to nodes is blocked by default
- ✅ Kubernetes API server access is controlled by EKS security groups

### GitLab Application Security

- Enable GitLab sign-in restrictions (LDAP/SAML only)
- Use strong root password
- Enable 2FA for all users
- Configure IP allowlists in GitLab settings
- Use AWS WAF on the load balancer for additional protection

### Alternative: Keep Internal LB with Public Subnet Nodes

If you want to keep GitLab internal-only:
1. Keep `aws-load-balancer-scheme: "internal"` in gitlab-values.yaml
2. Deploy nodes in public subnets (for outbound internet access)
3. Use self-signed certificates OR set up a private CA

## Troubleshooting

### Certificates Still Not Issuing

```bash
# Check certificate status
kubectl -n gitlab describe certificate gitlab-gitlab-tls

# Check challenge status
kubectl -n gitlab describe challenge <challenge-name>

# Common issues:
# 1. DuckDNS IP not updated - verify with: dig nhqb-gitlab.duckdns.org
# 2. Load balancer not ready - check: kubectl -n gitlab get svc
# 3. DNS propagation delay - wait 2-5 minutes
```

### Load Balancer Not Getting Public IP

```bash
# Check service events
kubectl -n gitlab describe svc gitlab-nginx-ingress-controller

# Verify annotation is correct
kubectl -n gitlab get svc gitlab-nginx-ingress-controller -o yaml | grep scheme

# Should show: service.beta.kubernetes.io/aws-load-balancer-scheme: internet-facing
```

### Nodes Not Getting Public IPs

```bash
# Verify node subnet has map_public_ip_on_launch enabled
aws ec2 describe-subnets --subnet-ids <subnet-id> \
  --query 'Subnets[0].MapPublicIpOnLaunch'

# Should return: true

# Check node group configuration
aws eks describe-nodegroup \
  --cluster-name ttb-terraform-k8s-cluster \
  --nodegroup-name <nodegroup-name> \
  --query 'nodegroup.subnets'
```

## Rollback Instructions

If you need to revert to private subnets:

```bash
cd d:\VTI\aws-rag-chatbot-ai\infra\terraform

# Edit terraform.tfvars
# Set: use_public_subnets = false

# Apply changes
terraform apply

# Update GitLab values back to internal load balancer
# Edit gitlab-values.yaml: change scheme back to "internal"

# Upgrade GitLab
helm upgrade gitlab gitlab/gitlab -n gitlab -f ./infra/k8s_cluster/gitlab/gitlab-values.yaml
```

## Summary

✅ **Completed Steps:**
1. Updated Terraform to support `use_public_subnets` variable
2. Created example terraform.tfvars with public subnet configuration
3. Provided instructions for updating GitLab to internet-facing load balancer

🔄 **Next Steps:**
1. Apply Terraform changes to deploy nodes in public subnets
2. Update GitLab Helm values for internet-facing load balancer
3. Update DuckDNS with new public IP
4. Verify Let's Encrypt certificates are issued successfully
