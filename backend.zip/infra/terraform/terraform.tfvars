# Terraform Variables Configuration
# Deploy EKS nodes in public subnets for HTTP-01 ACME challenges

project_name       = "ttb-terraform"
aws_region         = "ap-northeast-1"
cluster_name       = "ttb-terraform-k8s-cluster"

# Network Configuration
vpc_cidr = "10.0.0.0/16"
azs      = ["ap-northeast-1a", "ap-northeast-1c"]

# EKS Configuration
kubernetes_version = "1.34"

# Node Group Configuration
node_desired_size  = 2
node_max_size      = 3
node_min_size      = 1
node_instance_type = "m5.xlarge"

# Enable nodes in public subnets (required for HTTP-01 ACME challenges)
use_public_subnets = true

# Add-ons Configuration
enable_ebs_addon           = true
create_iam_oidc_provider   = true
